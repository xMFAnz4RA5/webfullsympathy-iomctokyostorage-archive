# iomc東京倉庫
iomc東京倉庫のツールを揃えています。

## 使用ツール/ライブラリ
- Bulma
- Bootstrap Icons
- Next.js

## 開発

## アイテム登録者へ
[こちら](itemgroup.md)をご覧ください。

### 開発環境
```bash
npm install
npm run dev
```

### 本番環境テスト
```bash
npm install
npm run build
npm run start
```
