export type User = {
    id: string;
    password: string;
    num: number;
};